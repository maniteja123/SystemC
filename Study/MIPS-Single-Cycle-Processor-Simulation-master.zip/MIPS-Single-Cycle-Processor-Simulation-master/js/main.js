

var canvas = document.getElementById("diagram");
var ctx = canvas.getContext("2d");

// xy mapping: http://www.mobilefish.com/services/record_mouse_coordinates/record_mouse_coordinates.php

// booleans indicating use when executing a MIPS instruction
var active = {
	connector : {},
	orangeConnector : {},
	register : {},
	ALU : {},
	control : {},
	otherOp : {},
	mux : {},
	andGate : false,
};	


var drawMux = function(shape) {
	var radius = 13;
	var centerX = shape[0][0];
	var topCenterY = shape[0][1] + radius;
	var bottomCenterY = shape[1][1] - radius;
	var leftLineX = centerX - radius;
	var rightLineX = centerX + radius;

	ctx.beginPath();
	ctx.arc(centerX, topCenterY, 13, Math.PI, 2*Math.PI, false)  
	ctx.lineTo(rightLineX, bottomCenterY);
	ctx.arc(centerX, bottomCenterY, 13, 0, Math.PI, false);
	ctx.lineTo(leftLineX, topCenterY);  
	ctx.stroke();

	ctx.font = "16px helvetica";
	ctx.fillText("0", centerX - 10, topCenterY + 10);
	ctx.fillText("1", centerX - 10, bottomCenterY + 5);
	ctx.font = "bold 14px helvetica";
	ctx.fillText("M", centerX - 7, (topCenterY + bottomCenterY)/2 - 7)
	ctx.fillText("U", centerX - 6, (topCenterY + bottomCenterY)/2 + 6)
	ctx.fillText("X", centerX - 6, (topCenterY + bottomCenterY)/2 + 18)

}

var drawOrangeLine = function(line, active) {
	if (active) {
		ctx.strokeStyle = "#eb6b00";
		ctx.lineWidth = 3;
	} else {
		ctx.strokeStyle = "#eb6b00";
		ctx.lineWidth = 1;
	}
	ctx.beginPath();
	ctx.moveTo(line[0][0], line[0][1]);
	for (var i = 1; i < line.length; i++) {
		ctx.lineTo(line[i][0], line[i][1]);
	}
	ctx.stroke();
}

var drawBlackLine = function(line, active) {
	if (active) {
		ctx.strokeStyle = "red";
		ctx.lineWidth = 3;
	} else {
		ctx.strokeStyle = "#000000";
		ctx.lineWidth = 1;
	}
	ctx.beginPath();
	ctx.moveTo(line[0][0], line[0][1]);
	for (var i = 1; i < line.length; i++) {
		ctx.lineTo(line[i][0], line[i][1]);
	}
	ctx.stroke();
}

var drawRegister = function(box) {
	ctx.strokeStyle = "#000000";
	ctx.lineWidth = 1;
	ctx.strokeRect(box[0][0], box[0][1], box[1][0] - box[0][0], box[1][1] - box[0][1]);
}

var drawALU = function(shape) {
	var x = shape[0];
	var y = shape[1];

	ctx.strokeStyle = "#000000";
	ctx.lineWidth = 1;
	ctx.beginPath();
	ctx.moveTo(x + 0, y + 0);
	ctx.lineTo(x + 92, y + 48);
	ctx.lineTo(x + 92, y + 103);
	ctx.lineTo(x + 0, y + 149);
	ctx.lineTo(x + 0, y + 92);
	ctx.lineTo(x + 17, y + 78);
	ctx.lineTo(x + 0, y + 63);
	ctx.lineTo(x + 0, y + 0);
	ctx.stroke();
}

var drawControl = function(shape) {
	var centerX = (shape[0][0] + shape[1][0])/2;
	var centerY = (shape[2][1] + shape[3][1])/2;
	var radius = (shape[1][0] - shape[0][0])/2;
	var scale = (shape[2][1] - shape[3][1])/(shape[0][0] - shape[1][0])

	//console.log(centerX, centerY, radius, scale);
	ctx.save();
	ctx.translate(centerX, centerY);
	ctx.scale(1, scale);
	ctx.beginPath();
	ctx.arc(0, 0, radius, 0, 2 * Math.PI, false);
	ctx.strokeStyle = "eb6b00";
	ctx.lineWidth = 1;
	ctx.stroke();
	ctx.restore();
}


var drawOps = function(shape) {
	var centerX = (shape[0][0] + shape[1][0])/2;
	var centerY = (shape[2][1] + shape[3][1])/2;
	var radius = (shape[1][0] - shape[0][0])/2;
	var scale = (shape[2][1] - shape[3][1])/(shape[0][0] - shape[1][0])

	//console.log(centerX, centerY, radius, scale);
	ctx.save();
	ctx.translate(centerX, centerY);
	ctx.scale(1, scale);
	ctx.beginPath();
	ctx.arc(0, 0, radius, 0, 2 * Math.PI, false);
	ctx.strokeStyle = "000000";
	ctx.lineWidth = 1;
	ctx.stroke();
	ctx.restore();
}

var drawAndGate = function(shape) {
	var x = shape[0];
	var y = shape[1];

	ctx.strokeStyle = "eb6b00";
	ctx.beginPath();
	ctx.moveTo(x, y);
	ctx.lineTo(x + 28, y);
	ctx.arc(x + 28, y + 18, 18, 1.5 * Math.PI, 0.5 * Math.PI, false);
	ctx.lineTo(x, y + 36);
	ctx.lineTo(x, y);
	ctx.stroke();
}

var drawText = function() {
	//PC
    ctx.textAlign = 'center';
	ctx.font = "bold 16px helvetica";
	ctx.fillText("PC", (registers.PC[0][0] + registers.PC[1][0])/2, (registers.PC[0][1] + registers.PC[1][1])/2 + 3.5);

	//IM
    ctx.textAlign = 'left';
	ctx.font = "bold 16px helvetica";
	ctx.fillText("Instruction", registers.IM[0][0] + 10, registers.IM[1][1] - 30);
	ctx.fillText("Memory", registers.IM[0][0] + 10, registers.IM[1][1] - 15);
	ctx.font = "14px helvetica";
	ctx.fillText("Read",  registers.IM[0][0] + 5, connectors.PCToIM[1][1] - 7.5);
	ctx.fillText("Memory",  registers.IM[0][0] + 5, connectors.PCToIM[1][1] + 7.5);
    ctx.textAlign = 'right';
	ctx.fillText("Instruction",  registers.IM[1][0] - 5, connectors.IMToControl[1][1] - 7.5);
	ctx.fillText("[31-0]",  registers.IM[1][0] - 5, connectors.IMToControl[1][1] + 7.5);

	//Register
    ctx.textAlign = 'center';
	ctx.font = "bold 16px helvetica";
    ctx.fillText("Registers", (registers.main[0][0] + registers.main[1][0])/2, (registers.main[0][1] + registers.main[1][1])/2 + 3.5);
    ctx.textAlign = 'left';
	ctx.font = "14px helvetica";
	ctx.fillText("Read",  registers.main[0][0] + 5, connectors.IMToReadRegister1[3][1] - 5.5);
	ctx.fillText("register 1",  registers.main[0][0] + 5, connectors.IMToReadRegister1[3][1] + 9.5);
	ctx.fillText("Read",  registers.main[0][0] + 5, connectors.IMToReadRegister2[3][1] - 7.5);
	ctx.fillText("register 2",  registers.main[0][0] + 5, connectors.IMToReadRegister2[3][1] + 7.5);
	ctx.fillText("Write",  registers.main[0][0] + 5, connectors.MuxToWriteRegister[1][1] - 6.5);
	ctx.fillText("register",  registers.main[0][0] + 5, connectors.MuxToWriteRegister[1][1] + 8.5);
	ctx.fillText("Write",  registers.main[0][0] + 5, connectors.MuxToRegWriteData[5][1] - 6.5);
	ctx.fillText("data",  registers.main[0][0] + 5, connectors.MuxToRegWriteData[5][1] + 8.5);
    ctx.textAlign = 'right';
	ctx.fillText("Read",  registers.main[1][0] - 5, connectors.ReadData1ToALU[0][1] - 7.5);
	ctx.fillText("data 1",  registers.main[1][0] - 5, connectors.ReadData1ToALU[0][1] + 7.5);
	ctx.fillText("Read",  registers.main[1][0] - 5, connectors.ReadData2ToALU[0][1] - 7.5);
	ctx.fillText("data 2",  registers.main[1][0] - 5, connectors.ReadData2ToALU[0][1] + 7.5);

    //DM
    ctx.textAlign = 'right';
    ctx.font = "bold 16px helvetica";
    ctx.fillText("Data", registers.DM[1][0] - 10, registers.DM[1][1] - 30);
    ctx.fillText("Memory", registers.DM[1][0] - 10, registers.DM[1][1] - 15);
    ctx.textAlign = 'left';
	ctx.font = "14px helvetica";
	ctx.fillText("Address",  registers.DM[0][0] + 5, connectors.ALUToDMAddress[1][1] + 3.5);
	ctx.fillText("Write",  registers.DM[0][0] + 5, connectors.ReadData2toDMWrite[1][1] - 7.5);
	ctx.fillText("data",  registers.DM[0][0] + 5, connectors.ReadData2toDMWrite[1][1] + 7.5);
    ctx.textAlign = 'right';
	ctx.fillText("Write",  registers.DM[1][0] - 5, connectors.DMWriteDataToMux1[0][1] - 7.5);
	ctx.fillText("data",  registers.DM[1][0] - 5, connectors.DMWriteDataToMux1[0][1] + 7.5);

    //Control
    ctx.textAlign = 'center';
    ctx.font = "bold 16px helvetica";
    ctx.save();
    ctx.fillStyle = "eb6b00";
    ctx.fillText('Control', (controls.main[0][0] + controls.main[1][0])/2, (controls.main[0][1] + controls.main[1][1])/2 + 3.5);
    ctx.restore();

    //ALU Control
    ctx.textAlign = 'center';
    ctx.font = "bold 15px helvetica";
    ctx.save();
    ctx.fillStyle = "eb6b00";
    ctx.fillText('ALU', (controls.ALUControl[0][0] + controls.ALUControl[1][0])/2, (controls.ALUControl[0][1] + controls.ALUControl[1][1])/2 - 7.5);
    ctx.fillText('Control', (controls.ALUControl[0][0] + controls.ALUControl[1][0])/2, (controls.ALUControl[0][1] + controls.ALUControl[1][1])/2 + 7.5);
    ctx.restore();

    //Sign Extend
    ctx.textAlign = 'center';
    ctx.font = "bold 15px helvetica";
    ctx.fillText('Sign', (otherOps.signExtend[0][0] + otherOps.signExtend[1][0])/2, (otherOps.signExtend[0][1] + otherOps.signExtend[1][1])/2 - 4)
    ctx.fillText('Extend', (otherOps.signExtend[0][0] + otherOps.signExtend[1][0])/2, (otherOps.signExtend[0][1] + otherOps.signExtend[1][1])/2 + 11);

    //Shift Left 2
    ctx.textAlign = 'center';
    ctx.font = "bold 14px helvetica";
    ctx.fillText('Shift', (otherOps.shiftLeft2[0][0] + otherOps.shiftLeft2[1][0])/2, (otherOps.shiftLeft2[0][1] + otherOps.shiftLeft2[1][1])/2 - 4)
    ctx.fillText('Left 2', (otherOps.shiftLeft2[0][0] + otherOps.shiftLeft2[1][0])/2, (otherOps.shiftLeft2[0][1] + otherOps.shiftLeft2[1][1])/2 + 11);

    //ALU
    ctx.textAlign = 'center';
	ctx.font = "bold 16px helvetica";
	ctx.fillText("ALU", ALUs.main[0] + 40, ALUs.main[1] + 82);
	ctx.textAlign = 'right';
    ctx.font = "14px helvetica";
	ctx.fillText("ALU",  ALUs.main[0] + 92 - 5, ALUs.main[1] + 95 - 7.5);
	ctx.fillText("result",  ALUs.main[0] + 92 - 5,  ALUs.main[1] + 95 + 6.5);
    ctx.save();
    ctx.fillStyle = "eb6b00";
	ctx.fillText("Zero",  ALUs.main[0] + 92 - 5, ALUs.main[1] + 65 - 7.5);
    ctx.restore();

    //Add 4
    ctx.textAlign = 'center';
	ctx.font = "bold 16px helvetica";
	ctx.fillText("Add", ALUs.Add4[0] + 45, ALUs.Add4[1] + 82);
    ctx.font = "16px helvetica";
    ctx.textAlign = 'right';
    ctx.fillText("4", connectors.ConstToAdd4[0][0] - 5, connectors.ConstToAdd4[0][1] + 3.5);

    //Add Offset
    ctx.textAlign = 'center';
	ctx.font = "bold 16px helvetica";
	ctx.fillText("Add", ALUs.addOffset[0] + 35, ALUs.addOffset[1] + 82);
	ctx.textAlign = 'right';
    ctx.font = "14px helvetica";
	ctx.fillText("ALU",  ALUs.addOffset[0] + 92 - 3, ALUs.addOffset[1] + 80 - 7.5);
	ctx.fillText("result",  ALUs.addOffset[0] + 92 - 3,  ALUs.addOffset[1] + 80 + 6.5);
    
	// instruction captions
	ctx.textAlign = 'left';
	ctx.font = "14px helvetica";
	ctx.fillText("Instruction [31-26]",  connectors.IMToControl[1][0] + 10, connectors.IMToControl[2][1] - 7);
	ctx.fillText("Instruction [25-21]",  connectors.IMToControl[1][0] + 10, connectors.IMToReadRegister1[2][1] - 7);
	ctx.fillText("Instruction [20-16]",  connectors.IMToControl[1][0] + 10, connectors.IMToReadRegister2[2][1] - 7);
	ctx.fillText("Instruction [15-11]",  connectors.IMToControl[1][0] + 10, connectors.IMToMux1[2][1] - 7);
	ctx.fillText("Instruction [10-0]",  connectors.IMToControl[1][0] + 10, connectors.IMToSignExtended[2][1] - 7);
	ctx.fillText("Instruction [10-0]",  connectors.IMToALUControl[1][0] + 10, connectors.IMToALUControl[1][1] - 7);
    ctx.save();
    ctx.fillStyle = "eb6b00";
    var control_captions = ["RegDst", "Branch", "MemRead", "MemtoReg", "ALUOp", "MemWrite", "ALUSrc", "RegWrite"];
    for (var i = 0; i < control_captions.length; i++)
		ctx.fillText(control_captions[i],  controls.main[1][0] + 4, orangeConnectors.RegDetToMux[0][1] - 3 + 20 * i);
	ctx.fillText("PCSrc",  orangeConnectors.ANDGateToMux1[1][0] + 5, orangeConnectors.RegDetToMux[2][1] + 10);

    ctx.restore();


}

var draw = function() {

	ctx.scale(0.75, 0.75);

	for (var line in connectors) {
		drawBlackLine(connectors[line], active.connector[line]);
	}

	for (var line in orangeConnectors){
		drawOrangeLine(orangeConnectors[line], active.orangeConnector[line]);
	}

	for (var box in registers) {
		drawRegister(registers[box]);
	}

	for (var shape in ALUs) {
		drawALU(ALUs[shape]);
	}

	for (var shape in controls) {
		drawControl(controls[shape]);
	}

	for (var shape in otherOps) {
		drawOps(otherOps[shape]);
	}


	for (var shape in muxes) {
		drawMux(muxes[shape]);
	}

	drawAndGate(andGate);

	drawText();

};

var initiate = function() {
	for (var line in connectors) {
		active.connector[line] = false;
	}

	for (var line in orangeConnectors){
		active.orangeConnector[line] = false;
	}

	for (var box in registers) {
		active.register[box] = false;
	}

	for (var shape in ALUs) {
		active.ALU[shape] = false;
	}

	for (var shape in controls) {
		active.control[shape] = false;
	}

	for (var shape in otherOps) {
		active.otherOp[shape] = false;
	}

	for (var shape in muxes) {
		active.mux[shape] = false;
	}
}

initiate();
draw();